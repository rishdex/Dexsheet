import auth0Service from './auth0Service';

export default auth0Service;
