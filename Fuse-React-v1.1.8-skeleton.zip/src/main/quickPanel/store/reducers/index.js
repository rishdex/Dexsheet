import quickPanel from './quickPanel.reducer';

const quickPanelReducers = quickPanel;

export default quickPanelReducers;