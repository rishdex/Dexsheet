import firebaseService from './firebaseService';

export default firebaseService;
